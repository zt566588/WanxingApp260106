const fs = require('fs');
const path = require('path');

// 数据文件路径
const DATA_FILE = path.join(process.cwd(), 'data', 'links.json');

// 确保数据目录存在
function ensureDataDir() {
  const dataDir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([]));
  }
}

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Content-Type': 'application/json'
};

exports.handler = async (event, context) => {
  ensureDataDir();

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    switch (event.httpMethod) {
      case 'GET':
        // 获取所有链接
        const data = fs.readFileSync(DATA_FILE, 'utf8');
        const links = JSON.parse(data);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(links)
        };

      case 'POST':
        // 添加新链接
        const body = JSON.parse(event.body);
        const { name, url, image } = body;
        
        if (!name || !url) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: '名称和URL是必填项' })
          };
        }

        const links = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        links.push({
          id: Date.now().toString(),
          name,
          url,
          image: image || 'https://via.placeholder.com/250x150?text=No+Preview'
        });
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(links, null, 2));
        
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };

      case 'DELETE':
        // 删除链接
        const id = event.path.split('/').pop();
        let allLinks = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        allLinks = allLinks.filter(link => link.id !== id);
        
        fs.writeFileSync(DATA_FILE, JSON.stringify(allLinks, null, 2));
        
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };

      default:
        return {
          statusCode: 405,
          headers: corsHeaders,
          body: JSON.stringify({ error: '方法不允许' })
        };
    }
  } catch (err) {
    console.error('Function error:', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: '服务器内部错误' })
    };
  }
};